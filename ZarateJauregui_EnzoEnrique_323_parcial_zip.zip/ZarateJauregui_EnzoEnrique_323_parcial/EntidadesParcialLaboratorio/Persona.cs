﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesParcialLaboratorio
{
    public abstract class Persona
    {
        protected string nombre;
        protected string apellido;
        protected string barrioResidencia;
        protected DateTime nacimiento;

        public Persona(string nombre, string apellido, DateTime nacimiento)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacimiento = nacimiento;
            this.barrioResidencia = string.Empty;
        }
        public Persona(string nombre, string apellido, DateTime nacimiento, string barrioResidencia):this(nombre,apellido,nacimiento)
        {
            this.barrioResidencia = barrioResidencia;
        }

        public int Edad
        {
            get
            {
                return DateTime.Today.AddTicks(-this.nacimiento.Ticks).Year - 1;
            }
        }
        public string NombreCompleto 
        {
            get
            {
                return $"{this.apellido}, {this.nombre}.";
            }
        }

        public override string ToString()
        {
            return this.NombreCompleto;
        }
        public static string FichaPersonal(Persona p)
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendLine(p.NombreCompleto);
            stringBuilder.AppendLine($"EDAD: {p.Edad}");
            stringBuilder.AppendLine(p.FichaExtra());

            return stringBuilder.ToString();
        }
        internal abstract string FichaExtra();
    }
}

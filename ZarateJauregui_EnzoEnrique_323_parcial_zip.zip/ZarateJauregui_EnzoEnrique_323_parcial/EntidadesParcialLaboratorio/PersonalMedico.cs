﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesParcialLaboratorio
{
    public class PersonalMedico: Persona
    {
        private List<Consulta> consulta;
        private bool esResidente;

        public PersonalMedico(string nombre, string apellido, DateTime nacimiento, bool esResidente) : base(nombre, apellido, nacimiento)
        {
            this.esResidente = esResidente;
            this.consulta = new List<Consulta>();
        }
        internal override string FichaExtra()
        {
            StringBuilder sb = new StringBuilder();

            string esResidente = this.esResidente ? "SI" : "NO";

            sb.AppendLine($"Finalizo residencia? {esResidente}");
            sb.AppendLine("ATENCIONES:");

            if(consulta.Count > 0)
            {
                foreach(var consulta in consulta) 
                {
                    if(consulta is not null)
                    {
                        sb.AppendLine(consulta.ToString());
                    }
                }
            }
            else
            {
                sb.AppendLine("No realizo consultas");
            }

            return sb.ToString();
        }
        public static Consulta operator +(PersonalMedico doctor, Paciente paciente)
        {
            Consulta nuevaConsulta = new Consulta(DateTime.Now, paciente);
            doctor.consulta.Add(nuevaConsulta);
            return nuevaConsulta;
        }
    }
}

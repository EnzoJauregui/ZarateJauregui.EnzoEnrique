using EntidadesParcialLaboratorio;

namespace ZarateJauregui.EnzoEnrique._323
{
    public partial class FrmAtencion : Form
    {
        public FrmAtencion()
        {
            InitializeComponent();
        }

        private void btnAtender_Click(object sender, EventArgs e)
        {
            bool flagVerificarSeleccion = false;
            string mensajeError = string.Empty;

            Paciente paciente = lstPacientes.SelectedItem as Paciente;
            PersonalMedico personalMedico = lstMedicos.SelectedItem as PersonalMedico;

            if (lstPacientes.SelectedItems.Count == 0 || lstMedicos.SelectedItems.Count == 0)
            {
                MessageBox.Show("Debe seleccionar un Medico y un Paciente para poder continuar.", "Error en los datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (paciente is not null || personalMedico is not null)
                {
                    paciente.Diagnostico = "Paciente curado";
                    Consulta consulta = personalMedico + paciente;
                    rtbInfoMedico.Text = Persona.FichaPersonal(personalMedico);
                    MessageBox.Show(consulta.ToString(), "Atencion Finalizada", MessageBoxButtons.OK);
                }
            }
            
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Seguro que desea salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            
            {
                this.Close();
            } 
        }

        private void lstMedicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstMedicos.SelectedIndex != -1)
            {
                PersonalMedico personalMedico = (PersonalMedico)lstMedicos.SelectedItem;

                rtbInfoMedico.Text = Persona.FichaPersonal(personalMedico);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lstMedicos.Items.Add(new PersonalMedico("Gustavo", "Rivas", new DateTime(1999, 12, 12), false));
            lstMedicos.Items.Add(new PersonalMedico("Lautaro", "Galarza", new DateTime(1951, 11, 12), true));
            lstPacientes.Items.Add(new Paciente("Mathias", "Bustamante", new DateTime(1998, 6, 16), "Tigre"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Ferrini", new DateTime(1989, 1, 21), "DF"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Rodriguez", new DateTime(1912, 12, 12), "LaBoca"));
            lstPacientes.Items.Add(new Paciente("John Jairo", "Trelles", new DateTime(1978, 8, 30), "Medellin"));

            lstMedicos.SelectedIndexChanged += lstMedicos_SelectedIndexChanged;
        }

    }
}
